# MRI-Brain-Segmentation-and-3D-Reconstruction-of-Brain
## Written by-
### Md. Kamrul Hasan 
### Erasmus Scholar on Medical Imaging and Application (MAIA) [http://maiamaster.udg.edu/]
[![MKH](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)] <br />
This project has been implemented after getting inspiration from the following links: 
+ https://fr.mathworks.com/matlabcentral/fileexchange/4879-mri-brain-segmentation
+ https://fr.mathworks.com/videos/medical-image-processing-with-matlab-81890.html?elqsid=1537713560421&potential_use=Student 
